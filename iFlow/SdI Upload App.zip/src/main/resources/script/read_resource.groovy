import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
import java.util.zip.ZipEntry;


import org.apache.camel.CamelContext;
import org.apache.camel.builder.RouteBuilder;
import org.apache.camel.impl.DefaultCamelContext;

import org.apache.camel.spi.Language;
import org.apache.camel.Expression;

def Message processData(Message message) {
    
    
    def camelHttpPath = message.getHeaders().get('CamelHttpPath');
    
    def httpPrefix = message.getHeaders().get('httpPrefix');
    def resourceFilename = message.getHeaders().get('rbundle');
    
// 'src/main/resources/lib/TableStarterPage_SAPFioriFundamentals.jar'
       InputStream rs = getClass().getResourceAsStream(resourceFilename)
       //byte[] zipbody = rs.getBytes();
       

   StringBuffer fileNames = new StringBuffer();
   HashMap files = new HashMap();
   
   fileNames.append("camelHttpPath: "+camelHttpPath+"\n");
   fileNames.append("rbundle: "+resourceFilename+"\n");
   fileNames.append("httpPrefix: "+httpPrefix+"\n");
    
    def boolean found  = false;
    

  def zipStream = new java.util.zip.ZipInputStream(rs);
  def stringBuffer = new StringBuffer();
  ZipEntry entry=zipStream.getNextEntry();
  byte[] buf=new byte[1024];
  while (entry != null) {
     
    String fname = entry.getName();
    ByteArrayOutputStream out=new ByteArrayOutputStream();
    int n;
    while ((n=zipStream.read(buf,0,1024)) > -1) {
      out.write(buf,0,n);
    }
     
    byte[] fbody = out.toByteArray();
     
    files.put(fname, fbody);
    
    def fullName = httpPrefix + fname;
    fileNames.append("file: "+fullName+"\n");
    
    if (fullName.equals(camelHttpPath)) {
        
         byte[] targetBody = procesCamelSimple(message, fname, fbody);
         message.setBody(targetBody);
         message.getHeaders().put("Content-Type", guessContentType(fname));
         found = true;
    }
     
    zipStream.closeEntry();
    entry=zipStream.getNextEntry();
  }
  
  fileNames.append("found: "+found+"\n");
    
    message.getProperties().put("load-jar-log",fileNames.toString());

    return message;
}



def Message loadResource(Message message) {

    def resourceName = message.getHeaders().get('rname');
    def resourceFilename = message.getHeaders().get('rbundle');
    
    InputStream rs = getClass().getResourceAsStream(resourceFilename)
       

   StringBuffer fileNames = new StringBuffer();
   
   fileNames.append("rname: "+resourceName+"\n");
   fileNames.append("rbundle: "+resourceFilename+"\n");
    
    def boolean found  = false;
    

  def zipStream = new java.util.zip.ZipInputStream(rs);
  def stringBuffer = new StringBuffer();
  ZipEntry entry=zipStream.getNextEntry();
  byte[] buf=new byte[1024];
  while (entry != null) {
     
    String fname = entry.getName();
    ByteArrayOutputStream out=new ByteArrayOutputStream();
    int n;
    while ((n=zipStream.read(buf,0,1024)) > -1) {
      out.write(buf,0,n);
    }
     
    byte[] fbody = out.toByteArray();
    
    fileNames.append("file: "+fname+"\n");
    
    if (fname.equals(resourceName)) {
         byte[] targetBody = procesCamelSimple(message, fname, fbody);
         message.setBody(targetBody);
         message.getHeaders().put("Content-Type", guessContentType(fname));
         found = true;
    }
     
    zipStream.closeEntry();
    entry=zipStream.getNextEntry();
  }
  
  fileNames.append("found: "+found+"\n");
  message.getProperties().put("loadResource-log",fileNames.toString());
  return message;

}



def byte[] procesCamelSimple(Message message, String resourceName, byte[] body) {
    
    
    byte[] result = body;
    if (resourceName.endsWith('html') || resourceName.endsWith('jscamel') ){
        
      CamelContext camelContext =   message.exchange.getContext();
        
      Language language = camelContext.resolveLanguage('simple'); 
      Expression expression =  language.createExpression(new String(body)); 

      byte[] value = expression.evaluate(message.exchange, byte[].class);     
      
      result = value;
    }
    return result;
}


def String guessContentType(String filename) {
    String contentType = "application/text";
    
    if (filename.endsWith('.js')) contentType = 'application/json';
    if (filename.endsWith('.jscamel')) contentType = 'application/json';
    if (filename.endsWith('.css')) contentType = 'text/css';
    if (filename.endsWith('.html')) contentType = 'text/html';
    if (filename.endsWith('.chtml')) contentType = 'text/html';
    if (filename.endsWith('.xml')) contentType = 'text/xml';
    if (filename.endsWith('.jpg')) contentType = 'image/jpeg';
    if (filename.endsWith('.png')) contentType = 'image/png';
    
    
    
    return contentType;
    
    
}