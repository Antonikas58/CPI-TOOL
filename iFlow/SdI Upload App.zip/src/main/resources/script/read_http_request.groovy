import com.sap.gateway.ip.core.customdev.util.Message;
import java.util.HashMap;
def Message processData(Message message) {
    
    def map = message.getHeaders();
    def String url =map.get('CamelHttpUrl');
    def exp  = /https:\/\/([\d\w-\.]*)\/.*/;
    def matcher = url =~ exp

    def hostname = matcher[0][1];
    
    message.setProperty("param-hostname", hostname);
    return message;
}